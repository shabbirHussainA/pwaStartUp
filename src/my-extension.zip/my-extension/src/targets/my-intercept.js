//src/targets/my-intercept.js

// Get the Targetables manager
const { Targetables } = require("@magento/pwa-buildpack");

module.exports = (targets) => {
  // Create a Targetables factory bound to the TargetProvider (targets)
  const targetables = Targetables.using(targets);

  // Tell the build process to use an esModules loader for this extension
  targetables.setSpecialFeatures("esModules");

  // Create a TargetableModule instance representing the myList.js file
  // And provide it a TargetablePublisher to define the API
  // targetables.module("my-extension/src/myList.js", {
  //   // Provide a publish() function that accepts the extension's TargetProvider
  //   // and an instance of this TargetableModule
  //   publish(myTargets, self) {
  //     // Define the Target's API
  //     const myListContentAPI = {
  //       // Define an `addContent()` function for the API
  //       addContent(content) {
  //         // Use the `insertBeforeSource()` function to make source code changes
  //         self.insertBeforeSource(
  //           "]; // List content data",
  //           `\n\t\t"${content}",`
  //         );
  //       },
  //     };
  //     // Connect the API to the `myListContent` target
  //     myTargets.myListContent.call(myListContentAPI);
  //   },
  // });
};
