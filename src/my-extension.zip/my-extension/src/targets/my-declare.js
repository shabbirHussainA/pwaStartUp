// src/targets/my-declare.js

// declaring new module name mylistContent 
module.exports = (targets) => {
    targets.declare({
      myListContent: new targets.types.SyncWaterfall(["myListContent"]),
    });
  };
  