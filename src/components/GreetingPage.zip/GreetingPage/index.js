/* src/components/GreetingPage/index.js */

export { default } from "./greetingPage";
