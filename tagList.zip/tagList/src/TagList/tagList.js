import React from 'react'
import Tag from "./tag"
import classes from "./tagList.css";
function TagList({
    categoriesListData
}) {
    // extracting categories from categoriesListData prop 
    const {categories} = categoriesListData
    // if categories doesnot exist
    if(!categories) return null;
    // creating a list of tags through map function 
    console.log("this is my categories" + categories);
    const tagList = categories.map((category)=>{
        <Tag key={category.name} value={category} />
    })
  // Returns the list of Tag components inside a div container
  return <div className={classes.root}>{tagList}</div>;

}

export default TagList
