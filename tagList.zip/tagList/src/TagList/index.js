/* src/TagList/index.js */

export { default } from "./tagList";
