import React from 'react'
import Button from "@magento/venia-ui/lib/components/Button";
import { Link } from "@magento/venia-ui/lib/drivers";
import classes from "./tag.css";

function Tag({
    value
}) {
    const categoryUrlSuffix = ".html";
    //extracting name and UrlPath form the value prop
    const { name, url_path } = value;
    // creating a url to direct
    const url = `/${url_path}${categoryUrlSuffix}`;
    // classes for Button
    const buttonClasses = {
      root_lowPriority: classes.root,
      content: classes.content,
    };
  
    return (
        <Link className={classes.link} to={url}>
          <Button classes={buttonClasses} priority="low" type="button">
            {name}
          </Button>
        </Link>
      );
}

export default Tag
