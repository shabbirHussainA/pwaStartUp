import useProductCategoriesList from "../hooks/useProductCategoriesList";
// it takes the original input
export default (original) => {
    // it takes all the props and other arguments 
  return function useProductFullDetails(props, ...restArgs) {
    // extrating product from the props 
    const { product } = props;
    console.log({"from wrapper Product print": product})
    // Run the data fetch hook
    const categoriesListData = useProductCategoriesList({
      urlKey: product.url_key,
    });

    // Run the original, wrapped function
    const { productDetails, ...defaultReturnData } = original(
      props,
      ...restArgs
    );

    // Add the new data to the data returned by the original function
    return {
      ...defaultReturnData,
      productDetails: {
        ...productDetails,
        categoriesListData: categoriesListData,
      },
    };
  };
};
